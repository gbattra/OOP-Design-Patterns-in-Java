package rpg.interfaces;

/**
 * Interface for footgear objects.
 */
public interface IFootGear extends IGear {
}
