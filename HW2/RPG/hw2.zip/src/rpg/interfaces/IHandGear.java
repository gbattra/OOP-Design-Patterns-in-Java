package rpg.interfaces;

/**
 * Interface for handgear objects.
 */
public interface IHandGear extends IGear {
}
