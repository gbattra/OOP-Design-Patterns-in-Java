package rpg.interfaces;

/**
 * Interface for headgear objects.
 */
public interface IHeadGear extends IGear {
}
